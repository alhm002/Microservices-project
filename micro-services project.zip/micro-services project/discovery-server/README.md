# Discovery Server

Serveur Eureka utilisé pour enregistrer et découvrir les microservices.

## Démarrer

```powershell
mvn spring-boot:run
```

Le serveur est disponible sur :

```text
http://localhost:8761
```

Les services suivants doivent ensuite apparaître dans Eureka :

```text
CUSTOMER-SERVICE
INVENTORY-SERVICE
API-GATEWAY
BILLING-SERVICE
```

## Ordre de démarrage

```text
1. discovery-server
2. customer-service
3. inventory-service
4. api-gateway
```

Eureka doit être démarré avant les clients pour que ceux-ci puissent s'enregistrer immédiatement.
