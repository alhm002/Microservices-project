# Inventory Service

Microservice de gestion des produits, deuxième étape du projet de microservices.

Le service s'enregistre auprès du Discovery Server Eureka sur `http://localhost:8761/eureka`.

## Prérequis

- Java 21+
- Maven 3.9+ recommandé
- MySQL 8+ ou Docker Desktop
- Discovery Server lancé sur le port `8761` pour l'enregistrement Eureka

## Configuration MySQL locale

Le service utilise par défaut :

- base : `inventory_db`
- utilisateur : `root`
- mot de passe : `root`
- port : `3306`

Si ton mot de passe MySQL est différent, définis les variables suivantes avant le démarrage :

```powershell
$env:INVENTORY_DB_USERNAME="root"
$env:INVENTORY_DB_PASSWORD="TON_MOT_DE_PASSE"
```

La base `inventory_db` est créée automatiquement si l'utilisateur possède les droits nécessaires.

## Utiliser MySQL avec Docker

Depuis ce dossier :

```bash
docker compose up -d
```

Le conteneur est exposé sur le port `3307` afin d'éviter un conflit avec le MySQL local du Customer Service. Dans ce cas :

```powershell
$env:INVENTORY_DB_URL="jdbc:mysql://localhost:3307/inventory_db?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true"
$env:INVENTORY_DB_USERNAME="root"
$env:INVENTORY_DB_PASSWORD="root"
```

## Lancer le service

```bash
mvn spring-boot:run
```

Le service démarre sur `http://localhost:8082`.

## API

```text
GET    /api/products
GET    /api/products/{id}
POST   /api/products
PUT    /api/products/{id}
DELETE /api/products/{id}
```

Exemple de création :

```http
POST http://localhost:8082/api/products
Content-Type: application/json

{
  "name": "Clavier mécanique",
  "price": 249.90
}
```

Endpoints Actuator :

```text
GET /actuator/health
GET /actuator/info
```

## Tests

```bash
mvn test
```

Pour la production, remplace `spring.jpa.hibernate.ddl-auto=update` par une stratégie de migration avec Flyway ou Liquibase.
