package com.microservices.inventory.exception;

public class DuplicateProductNameException extends RuntimeException {

    public DuplicateProductNameException(String name) {
        super("Un produit avec le nom " + name + " existe déjà");
    }
}
