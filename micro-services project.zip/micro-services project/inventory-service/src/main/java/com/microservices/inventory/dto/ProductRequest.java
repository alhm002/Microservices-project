package com.microservices.inventory.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public record ProductRequest(
        @NotBlank(message = "Le nom du produit est obligatoire")
        @Size(max = 150, message = "Le nom du produit ne doit pas dépasser 150 caractères")
        String name,

        @NotNull(message = "Le prix est obligatoire")
        @DecimalMin(value = "0.01", message = "Le prix doit être supérieur à 0")
        @Digits(integer = 10, fraction = 2, message = "Le prix doit avoir au maximum 2 décimales")
        BigDecimal price
) {
}
