package com.microservices.inventory.service;

import com.microservices.inventory.dto.ProductRequest;
import com.microservices.inventory.dto.ProductResponse;
import com.microservices.inventory.entity.Product;
import com.microservices.inventory.exception.DuplicateProductNameException;
import com.microservices.inventory.exception.ProductNotFoundException;
import com.microservices.inventory.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Objects;

@Service
@Transactional(readOnly = true)
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<ProductResponse> findAll() {
        return productRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    public ProductResponse findById(Long id) {
        return toResponse(findEntityById(id));
    }

    @Transactional
    public ProductResponse create(ProductRequest request) {
        String name = normalizeName(request.name());
        ensureNameIsAvailable(name, null);

        Product product = new Product(name, normalizePrice(request.price()));
        return toResponse(productRepository.save(product));
    }

    @Transactional
    public ProductResponse update(Long id, ProductRequest request) {
        Product product = findEntityById(id);
        String name = normalizeName(request.name());
        ensureNameIsAvailable(name, id);

        product.setName(name);
        product.setPrice(normalizePrice(request.price()));
        return toResponse(productRepository.save(product));
    }

    @Transactional
    public void delete(Long id) {
        Product product = findEntityById(id);
        productRepository.delete(product);
    }

    private Product findEntityById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException(id));
    }

    private void ensureNameIsAvailable(String name, Long currentProductId) {
        productRepository.findByNameIgnoreCase(name)
                .filter(existing -> currentProductId == null
                        || !Objects.equals(existing.getId(), currentProductId))
                .ifPresent(existing -> {
                    throw new DuplicateProductNameException(name);
                });
    }

    private ProductResponse toResponse(Product product) {
        return new ProductResponse(product.getId(), product.getName(), product.getPrice());
    }

    private String normalizeName(String name) {
        return name.trim().replaceAll("\\s+", " ");
    }

    private BigDecimal normalizePrice(BigDecimal price) {
        return price.setScale(2, RoundingMode.HALF_UP);
    }
}
