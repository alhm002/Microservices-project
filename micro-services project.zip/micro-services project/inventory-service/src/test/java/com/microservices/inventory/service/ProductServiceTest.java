package com.microservices.inventory.service;

import com.microservices.inventory.dto.ProductRequest;
import com.microservices.inventory.dto.ProductResponse;
import com.microservices.inventory.entity.Product;
import com.microservices.inventory.exception.DuplicateProductNameException;
import com.microservices.inventory.exception.ProductNotFoundException;
import com.microservices.inventory.repository.ProductRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private ProductService productService;

    @Test
    void shouldCreateProductWithNormalizedValues() {
        Product savedProduct = new Product("Clavier mécanique", new BigDecimal("249.90"));
        when(productRepository.findByNameIgnoreCase("Clavier mécanique"))
                .thenReturn(Optional.empty());
        when(productRepository.save(any(Product.class))).thenReturn(savedProduct);

        ProductResponse result = productService.create(
                new ProductRequest("  Clavier   mécanique ", new BigDecimal("249.9")));

        assertThat(result.name()).isEqualTo("Clavier mécanique");
        assertThat(result.price()).isEqualByComparingTo("249.90");
        verify(productRepository).save(any(Product.class));
    }

    @Test
    void shouldRejectDuplicateProductName() {
        Product existing = new Product("Souris", new BigDecimal("99.90"));
        when(productRepository.findByNameIgnoreCase("Souris"))
                .thenReturn(Optional.of(existing));

        assertThatThrownBy(() -> productService.create(
                new ProductRequest("Souris", new BigDecimal("99.90"))))
                .isInstanceOf(DuplicateProductNameException.class);

        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    void shouldThrowWhenProductDoesNotExist() {
        when(productRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> productService.findById(99L))
                .isInstanceOf(ProductNotFoundException.class)
                .hasMessageContaining("99");
    }
}
