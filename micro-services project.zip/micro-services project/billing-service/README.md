# Billing Service

Microservice de gestion des factures. Il communique avec Customer Service et Inventory Service grâce à OpenFeign et Eureka.

## Architecture

```text
Billing Service :8083
       ├── OpenFeign → Customer Service
       └── OpenFeign → Inventory Service
```

La base `billing_db` appartient uniquement à Billing Service. Les identifiants `customerId` et `productId` sont vérifiés par appels REST ; aucune clé étrangère SQL ne relie les bases des microservices.

Le prix et le nom du produit sont copiés dans `ProductItem` au moment de la création de la facture. L'historique de la facture reste donc stable lorsque le produit change dans Inventory Service.

## Prérequis

- Discovery Server lancé sur `8761`
- Customer Service lancé et enregistré dans Eureka
- Inventory Service lancé et enregistré dans Eureka
- MySQL avec la base `billing_db`

## Configuration MySQL locale

Par défaut :

- base : `billing_db`
- utilisateur : `root`
- mot de passe : `root`
- port : `3306`

Si ton mot de passe est différent :

```powershell
$env:BILLING_DB_USERNAME="root"
$env:BILLING_DB_PASSWORD="TON_MOT_DE_PASSE"
```

## MySQL avec Docker

```powershell
docker compose up -d
```

Le conteneur utilise le port `3308` sur la machine hôte :

```powershell
$env:BILLING_DB_URL="jdbc:mysql://localhost:3308/billing_db?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true"
$env:BILLING_DB_USERNAME="root"
$env:BILLING_DB_PASSWORD="root"
```

## Lancer le service

```powershell
mvn spring-boot:run
```

Le service démarre sur `http://localhost:8083`.

## API

```text
GET    /api/bills
GET    /api/bills/{id}
POST   /api/bills
DELETE /api/bills/{id}
```

Exemple de création :

```http
POST http://localhost:8083/api/bills
Content-Type: application/json

{
  "customerId": 1,
  "items": [
    {
      "productId": 1,
      "quantity": 2
    }
  ]
}
```
