package com.microservices.billing.service;

import com.microservices.billing.client.CustomerClient;
import com.microservices.billing.client.CustomerClientResponse;
import com.microservices.billing.client.ProductClient;
import com.microservices.billing.client.ProductClientResponse;
import com.microservices.billing.dto.BillItemRequest;
import com.microservices.billing.dto.BillRequest;
import com.microservices.billing.dto.BillResponse;
import com.microservices.billing.exception.BillNotFoundException;
import com.microservices.billing.exception.DuplicateProductException;
import com.microservices.billing.repository.BillRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BillServiceTest {

    @Mock
    private BillRepository billRepository;

    @Mock
    private CustomerClient customerClient;

    @Mock
    private ProductClient productClient;

    @InjectMocks
    private BillService billService;

    @Test
    void shouldCreateBillAndCalculateTotal() {
        when(customerClient.findById(1L))
                .thenReturn(new CustomerClientResponse(1L, "Ahmed Alaoui", "ahmed@example.com"));
        when(productClient.findById(10L))
                .thenReturn(new ProductClientResponse(10L, "Clavier", new BigDecimal("250.00")));
        when(billRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        BillResponse result = billService.create(new BillRequest(
                1L,
                List.of(new BillItemRequest(10L, 3))
        ));

        assertThat(result.customer().name()).isEqualTo("Ahmed Alaoui");
        assertThat(result.items()).hasSize(1);
        assertThat(result.items().getFirst().lineTotal()).isEqualByComparingTo("750.00");
        assertThat(result.total()).isEqualByComparingTo("750.00");
    }

    @Test
    void shouldRejectDuplicateProductInBill() {
        assertThatThrownBy(() -> billService.create(new BillRequest(
                1L,
                List.of(new BillItemRequest(10L, 1), new BillItemRequest(10L, 2))
        ))).isInstanceOf(DuplicateProductException.class);

        verify(customerClient, never()).findById(any());
        verify(productClient, never()).findById(any());
    }

    @Test
    void shouldThrowWhenBillDoesNotExist() {
        when(billRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> billService.findById(99L))
                .isInstanceOf(BillNotFoundException.class)
                .hasMessageContaining("99");
    }
}
