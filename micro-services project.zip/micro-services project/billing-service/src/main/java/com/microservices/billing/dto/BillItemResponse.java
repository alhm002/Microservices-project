package com.microservices.billing.dto;

import java.math.BigDecimal;

public record BillItemResponse(
        Long id,
        Long productId,
        String productName,
        BigDecimal price,
        Integer quantity,
        BigDecimal lineTotal
) {
}
