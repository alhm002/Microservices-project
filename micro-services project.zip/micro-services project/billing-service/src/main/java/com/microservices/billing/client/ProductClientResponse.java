package com.microservices.billing.client;

import java.math.BigDecimal;

public record ProductClientResponse(
        Long id,
        String name,
        BigDecimal price
) {
}
