package com.microservices.billing.dto;

public record CustomerSummary(
        Long id,
        String name,
        String email
) {
}
