package com.microservices.billing.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "inventory-service")
public interface ProductClient {

    @GetMapping("/api/products/{id}")
    ProductClientResponse findById(@PathVariable("id") Long id);
}
