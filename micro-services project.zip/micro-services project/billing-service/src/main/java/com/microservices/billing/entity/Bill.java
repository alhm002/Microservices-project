package com.microservices.billing.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "bills")
public class Bill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "billing_date", nullable = false)
    private LocalDate billingDate;

    @Column(name = "customer_id", nullable = false)
    private Long customerId;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal total = BigDecimal.ZERO;

    @OneToMany(mappedBy = "bill", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<ProductItem> items = new ArrayList<>();

    protected Bill() {
        // Constructeur requis par JPA.
    }

    public Bill(LocalDate billingDate, Long customerId) {
        this.billingDate = billingDate;
        this.customerId = customerId;
    }

    public void addItem(ProductItem item) {
        items.add(item);
        item.setBill(this);
    }

    public Long getId() {
        return id;
    }

    public LocalDate getBillingDate() {
        return billingDate;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public List<ProductItem> getItems() {
        return items;
    }
}
