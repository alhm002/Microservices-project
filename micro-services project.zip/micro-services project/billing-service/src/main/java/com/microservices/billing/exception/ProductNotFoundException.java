package com.microservices.billing.exception;

public class ProductNotFoundException extends RuntimeException {

    public ProductNotFoundException(Long id) {
        super("Le produit avec l'id " + id + " n'existe pas dans Inventory Service");
    }
}
