package com.microservices.billing.exception;

public class RemoteServiceUnavailableException extends RuntimeException {

    public RemoteServiceUnavailableException(String serviceName) {
        super("Le service " + serviceName + " est indisponible");
    }
}
