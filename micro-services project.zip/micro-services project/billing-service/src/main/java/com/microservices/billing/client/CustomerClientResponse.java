package com.microservices.billing.client;

public record CustomerClientResponse(
        Long id,
        String name,
        String email
) {
}
