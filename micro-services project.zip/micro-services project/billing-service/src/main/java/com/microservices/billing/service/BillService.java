package com.microservices.billing.service;

import com.microservices.billing.client.CustomerClient;
import com.microservices.billing.client.CustomerClientResponse;
import com.microservices.billing.client.ProductClient;
import com.microservices.billing.client.ProductClientResponse;
import com.microservices.billing.dto.BillItemRequest;
import com.microservices.billing.dto.BillItemResponse;
import com.microservices.billing.dto.BillRequest;
import com.microservices.billing.dto.BillResponse;
import com.microservices.billing.dto.CustomerSummary;
import com.microservices.billing.entity.Bill;
import com.microservices.billing.entity.ProductItem;
import com.microservices.billing.exception.BillNotFoundException;
import com.microservices.billing.exception.CustomerNotFoundException;
import com.microservices.billing.exception.DuplicateProductException;
import com.microservices.billing.exception.ProductNotFoundException;
import com.microservices.billing.exception.RemoteServiceUnavailableException;
import com.microservices.billing.repository.BillRepository;
import feign.FeignException;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@Transactional(readOnly = true)
public class BillService {

    private final BillRepository billRepository;
    private final CustomerClient customerClient;
    private final ProductClient productClient;

    public BillService(
            BillRepository billRepository,
            CustomerClient customerClient,
            ProductClient productClient) {
        this.billRepository = billRepository;
        this.customerClient = customerClient;
        this.productClient = productClient;
    }

    public List<BillResponse> findAll() {
        return billRepository.findAll(Sort.by(Sort.Direction.DESC, "billingDate")).stream()
                .map(this::toResponseWithRemoteCustomer)
                .toList();
    }

    public BillResponse findById(Long id) {
        return toResponseWithRemoteCustomer(findEntityById(id));
    }

    @Transactional
    public BillResponse create(BillRequest request) {
        validateUniqueProducts(request.items());
        CustomerClientResponse customer = findCustomer(request.customerId());

        Bill bill = new Bill(LocalDate.now(), customer.id());
        BigDecimal total = BigDecimal.ZERO;

        for (BillItemRequest itemRequest : request.items()) {
            ProductClientResponse product = findProduct(itemRequest.productId());
            BigDecimal lineTotal = product.price().multiply(BigDecimal.valueOf(itemRequest.quantity()));

            bill.addItem(new ProductItem(
                    product.id(),
                    product.name(),
                    product.price(),
                    itemRequest.quantity()
            ));
            total = total.add(lineTotal);
        }

        bill.setTotal(total);
        Bill savedBill = billRepository.save(bill);
        return toResponse(savedBill, customer);
    }

    @Transactional
    public void delete(Long id) {
        billRepository.delete(findEntityById(id));
    }

    private Bill findEntityById(Long id) {
        return billRepository.findById(id)
                .orElseThrow(() -> new BillNotFoundException(id));
    }

    private CustomerClientResponse findCustomer(Long id) {
        try {
            return customerClient.findById(id);
        } catch (FeignException.NotFound exception) {
            throw new CustomerNotFoundException(id);
        } catch (FeignException exception) {
            throw new RemoteServiceUnavailableException("Customer Service");
        }
    }

    private ProductClientResponse findProduct(Long id) {
        try {
            return productClient.findById(id);
        } catch (FeignException.NotFound exception) {
            throw new ProductNotFoundException(id);
        } catch (FeignException exception) {
            throw new RemoteServiceUnavailableException("Inventory Service");
        }
    }

    private void validateUniqueProducts(List<BillItemRequest> items) {
        Set<Long> productIds = new HashSet<>();
        for (BillItemRequest item : items) {
            if (!productIds.add(item.productId())) {
                throw new DuplicateProductException(item.productId());
            }
        }
    }

    private BillResponse toResponseWithRemoteCustomer(Bill bill) {
        return toResponse(bill, findCustomer(bill.getCustomerId()));
    }

    private BillResponse toResponse(Bill bill, CustomerClientResponse customer) {
        List<BillItemResponse> items = bill.getItems().stream()
                .map(item -> new BillItemResponse(
                        item.getId(),
                        item.getProductId(),
                        item.getProductName(),
                        item.getPrice(),
                        item.getQuantity(),
                        item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity()))
                ))
                .toList();

        return new BillResponse(
                bill.getId(),
                bill.getBillingDate(),
                bill.getCustomerId(),
                new CustomerSummary(customer.id(), customer.name(), customer.email()),
                items,
                bill.getTotal()
        );
    }
}
