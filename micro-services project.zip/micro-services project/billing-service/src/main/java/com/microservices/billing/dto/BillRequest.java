package com.microservices.billing.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record BillRequest(
        @NotNull(message = "L'identifiant du client est obligatoire")
        Long customerId,

        @NotEmpty(message = "La facture doit contenir au moins un produit")
        List<@Valid BillItemRequest> items
) {
}
