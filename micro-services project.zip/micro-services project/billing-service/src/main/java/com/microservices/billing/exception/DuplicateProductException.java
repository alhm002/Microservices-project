package com.microservices.billing.exception;

public class DuplicateProductException extends RuntimeException {

    public DuplicateProductException(Long id) {
        super("Le produit avec l'id " + id + " apparaît plusieurs fois dans la facture");
    }
}
