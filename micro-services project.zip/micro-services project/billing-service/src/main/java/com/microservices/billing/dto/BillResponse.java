package com.microservices.billing.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record BillResponse(
        Long id,
        LocalDate billingDate,
        Long customerId,
        CustomerSummary customer,
        List<BillItemResponse> items,
        BigDecimal total
) {
}
