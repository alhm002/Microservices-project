package com.microservices.billing.exception;

public class BillNotFoundException extends RuntimeException {

    public BillNotFoundException(Long id) {
        super("La facture avec l'id " + id + " n'existe pas");
    }
}
