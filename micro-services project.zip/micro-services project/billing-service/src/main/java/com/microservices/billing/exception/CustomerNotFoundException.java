package com.microservices.billing.exception;

public class CustomerNotFoundException extends RuntimeException {

    public CustomerNotFoundException(Long id) {
        super("Le client avec l'id " + id + " n'existe pas dans Customer Service");
    }
}
