# API Gateway

Passerelle d'accès aux microservices Customer et Inventory avec découverte Eureka.

## Architecture actuelle

```text
Client → API Gateway :8080
             ├── /api/customers/** → Customer Service :8081
             ├── /api/products/**  → Inventory Service :8082
             └── /api/bills/**     → Billing Service :8083
```

Les routes sont configurées dans `src/main/resources/application.properties` avec les URI dynamiques `lb://customer-service` et `lb://inventory-service`. Eureka fournit les adresses des instances et Spring Cloud LoadBalancer sélectionne une instance.

Spring Cloud Gateway Server WebFlux utilise Netty/WebFlux. Le Gateway ne se connecte pas directement à MySQL et ne nécessite donc aucune configuration de base de données.

## Prérequis

- Java 21+
- Maven
- Discovery Server lancé sur `8761`
- Customer Service lancé sur `8081`
- Inventory Service lancé sur `8082`
- Billing Service lancé sur `8083`

## Lancer le Gateway

```powershell
mvn spring-boot:run
```

Le Gateway démarre sur :

```text
http://localhost:8080
```

## Tester les routes

```text
GET  http://localhost:8080/api/customers
GET  http://localhost:8080/api/products
GET  http://localhost:8080/api/bills
POST http://localhost:8080/api/customers
POST http://localhost:8080/api/products
POST http://localhost:8080/api/bills
```

Les requêtes reçues par le Gateway sont transférées vers le service correspondant.

## Configuration Java historique

Une variante statique en Java est disponible dans `JavaRoutesConfiguration` pour l'exercice de comparaison. Elle est désactivée par défaut ; la configuration active du projet est celle basée sur Eureka dans `application.properties`.

N'active pas cette variante en même temps que les routes dynamiques Eureka.

```powershell
mvn spring-boot:run "-Dspring-boot.run.profiles=java-routes"
```

Les URL restent identiques.

## Actuator

```text
GET http://localhost:8080/actuator/health
GET http://localhost:8080/actuator/info
```
