package com.microservices.gateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;


@Configuration
@Profile("java-routes")
public class JavaRoutesConfiguration {

    @Bean
    public RouteLocator customRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("customer-service-java", route -> route
                        .path("/api/customers/**")
                        .uri("http://localhost:8081"))
                .route("inventory-service-java", route -> route
                        .path("/api/products/**")
                        .uri("http://localhost:8082"))
                .build();
    }
}
