# Customer Service

Microservice de gestion des clients, première étape du projet de microservices.

Le service s'enregistre auprès du Discovery Server Eureka sur `http://localhost:8761/eureka`.

## Prérequis

- Java 21+
- Maven 3.9+ recommandé (Maven 3.6.3 fonctionne généralement avec ce projet)
- Docker Desktop, pour lancer MySQL
- Discovery Server lancé sur le port `8761` pour l'enregistrement Eureka

## Démarrage de MySQL

Depuis ce dossier :

```bash
docker compose up -d
```

La base `customer_db` est créée automatiquement avec :

- utilisateur : `root`
- mot de passe : `root`
- port MySQL : `3306`

Ces valeurs sont destinées au développement local. Elles peuvent être remplacées avec :

```text
CUSTOMER_DB_URL
CUSTOMER_DB_USERNAME
CUSTOMER_DB_PASSWORD
SERVER_PORT
```

## Lancer le service

```bash
mvn spring-boot:run
```

Le service démarre sur `http://localhost:8081`.

## API

```text
GET    /api/customers
GET    /api/customers/{id}
POST   /api/customers
PUT    /api/customers/{id}
DELETE /api/customers/{id}
```

Exemple de création :

```http
POST http://localhost:8081/api/customers
Content-Type: application/json

{
  "name": "Ahmed Ben Ali",
  "email": "ahmed@example.com"
}
```

Les endpoints de supervision disponibles sont :

```text
GET /actuator/health
GET /actuator/info
```

## Vérification

```bash
mvn test
mvn clean verify
```

Pour la production, remplace `spring.jpa.hibernate.ddl-auto=update` par une stratégie de migration avec Flyway ou Liquibase.
