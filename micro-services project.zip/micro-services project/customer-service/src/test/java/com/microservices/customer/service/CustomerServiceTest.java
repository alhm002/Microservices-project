package com.microservices.customer.service;

import com.microservices.customer.dto.CustomerRequest;
import com.microservices.customer.dto.CustomerResponse;
import com.microservices.customer.entity.Customer;
import com.microservices.customer.exception.CustomerNotFoundException;
import com.microservices.customer.exception.DuplicateEmailException;
import com.microservices.customer.repository.CustomerRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerService customerService;

    @Test
    void shouldCreateCustomerWithNormalizedValues() {
        Customer savedCustomer = new Customer("Ahmed Ben Ali", "ahmed@example.com");
        when(customerRepository.findByEmailIgnoreCase("ahmed@example.com"))
                .thenReturn(Optional.empty());
        when(customerRepository.save(any(Customer.class))).thenReturn(savedCustomer);

        CustomerResponse result = customerService.create(
                new CustomerRequest("  Ahmed   Ben Ali ", " AHMED@EXAMPLE.COM "));

        assertThat(result.name()).isEqualTo("Ahmed Ben Ali");
        assertThat(result.email()).isEqualTo("ahmed@example.com");
        verify(customerRepository).save(any(Customer.class));
    }

    @Test
    void shouldRejectDuplicateEmail() {
        Customer existing = new Customer("Existing", "existing@example.com");
        when(customerRepository.findByEmailIgnoreCase("existing@example.com"))
                .thenReturn(Optional.of(existing));

        assertThatThrownBy(() -> customerService.create(
                new CustomerRequest("New Customer", "existing@example.com")))
                .isInstanceOf(DuplicateEmailException.class);

        verify(customerRepository, never()).save(any(Customer.class));
    }

    @Test
    void shouldThrowWhenCustomerDoesNotExist() {
        when(customerRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> customerService.findById(99L))
                .isInstanceOf(CustomerNotFoundException.class)
                .hasMessageContaining("99");
    }
}
