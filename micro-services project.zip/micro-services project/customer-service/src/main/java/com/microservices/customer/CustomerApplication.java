package com.microservices.customer;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import com.microservices.customer.entity.Customer;
import com.microservices.customer.repository.CustomerRepository;


import java.util.List;

@SpringBootApplication
public class CustomerApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomerApplication.class, args);
    }

    @Bean
    CommandLineRunner run(CustomerRepository customerRepository) {
        return args -> {

            if (customerRepository.count() == 0) {

                List<Customer> customers = List.of(
                        new Customer(
                                "Ahmed Alaoui",
                                "ahmed@example.com"
                        ),
                        new Customer(
                                "Sara Bennani",
                                "sara@example.com"
                        ),
                        new Customer(
                                "Youssef Amrani",
                                "youssef@example.com"
                        ),
                        new Customer(
                                "Imane Naciri",
                                "imane@example.com"
                        ),
                        new Customer(
                                "Omar Idrissi",
                                "omar@example.com"
                        )
                );

                customerRepository.saveAll(customers);
            }
        };
    }
}
