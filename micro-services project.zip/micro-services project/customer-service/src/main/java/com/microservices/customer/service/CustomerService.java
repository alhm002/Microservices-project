package com.microservices.customer.service;

import com.microservices.customer.dto.CustomerRequest;
import com.microservices.customer.dto.CustomerResponse;
import com.microservices.customer.entity.Customer;
import com.microservices.customer.exception.CustomerNotFoundException;
import com.microservices.customer.exception.DuplicateEmailException;
import com.microservices.customer.repository.CustomerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Service
@Transactional(readOnly = true)
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public List<CustomerResponse> findAll() {
        return customerRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    public CustomerResponse findById(Long id) {
        return toResponse(findEntityById(id));
    }

    @Transactional
    public CustomerResponse create(CustomerRequest request) {
        String email = normalizeEmail(request.email());
        ensureEmailIsAvailable(email, null);

        Customer customer = new Customer(normalizeName(request.name()), email);
        return toResponse(customerRepository.save(customer));
    }

    @Transactional
    public CustomerResponse update(Long id, CustomerRequest request) {
        Customer customer = findEntityById(id);
        String email = normalizeEmail(request.email());
        ensureEmailIsAvailable(email, id);

        customer.setName(normalizeName(request.name()));
        customer.setEmail(email);
        return toResponse(customerRepository.save(customer));
    }

    @Transactional
    public void delete(Long id) {
        Customer customer = findEntityById(id);
        customerRepository.delete(customer);
    }

    private Customer findEntityById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new CustomerNotFoundException(id));
    }

    private void ensureEmailIsAvailable(String email, Long currentCustomerId) {
        customerRepository.findByEmailIgnoreCase(email)
                .filter(existing -> currentCustomerId == null
                        || !Objects.equals(existing.getId(), currentCustomerId))
                .ifPresent(existing -> {
                    throw new DuplicateEmailException(email);
                });
    }

    private CustomerResponse toResponse(Customer customer) {
        return new CustomerResponse(customer.getId(), customer.getName(), customer.getEmail());
    }

    private String normalizeName(String name) {
        return name.trim().replaceAll("\\s+", " ");
    }

    private String normalizeEmail(String email) {
        return email.trim().toLowerCase();
    }
}
