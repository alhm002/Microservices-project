package com.microservices.customer.exception;

public class DuplicateEmailException extends RuntimeException {

    public DuplicateEmailException(String email) {
        super("Un client avec l'email " + email + " existe déjà");
    }
}
